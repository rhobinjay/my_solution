# F1 Dashboard Web App
A dashboard that aims to provide race data about Formula 1 World Championship.

## Requirements
a. The dashboard must have a year column showing all the covered year data.
a.1 The year column should be sorted from the most recent to the oldest.
a.2 The year column must be clickable.
b. The dashboard must have a race name column showing the name of the circuit.
b.1 The race name column should be sorted alphabetically.
b.2 The race column must show the race name of the selected year.
b.3 The race name must be clickable.
c. The Median Pit Stop duration must be shown on the dashboard.
c.1 The unit of the duration must be in seconds.
c.2 The Median Pit Stop duration must be calculated and shown in the selected race name.

## Deployment
Build docker image `docker build -t f1_dashboard:0 .`
Run start service `docker container run -p 5000:5000 f1_dashboard:0`
