import pytest
import pandas as pd
from datetime import time

from f1_dashboard import datasource

@pytest.mark.parametrize('time, expected', [
    ('1.123', time(0, 0, 1, 123000)),
    ('4:3.942', time(0, 4, 3, 942000)),
    ('8:9:7.123', time(8, 9, 7, 123000)),
])
def test_convert_to_datetime_with_formats(time, expected):
    result = datasource.convert_to_datetime_with_formats(time)
    assert result == expected


@pytest.mark.parametrize('microsecond, expected', [
    (12312300, time(0, 0, 12, 312300)),
    (1231230000, time(0, 20, 31, 230000)),
])
def test_convert_microsecond_into_time(microsecond, expected):
    result = datasource.convert_microsecond_into_time(microsecond)
    assert result == expected


@pytest.mark.parametrize('time_obj, expected', [
    (time(0, 2, 31, 230000), 151230000),
    (time(0, 20, 31, 230000), 1231230000),
])
def test_convert_time_into_microsecond(time_obj, expected):
    result = datasource.convert_time_into_microsecond(time_obj)
    assert result == expected


def test_compute_median():
    series = pd.Series(data=[
        time(0, 0, 1, 000000),
        time(0, 0, 2, 000000),
        time(0, 0, 3, 000000),
    ])
    result = datasource.compute_median(series)
    expected = time(0, 0, 2)
    assert result == expected
