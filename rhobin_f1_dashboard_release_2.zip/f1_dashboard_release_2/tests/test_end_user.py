import json


def test_pit_stops_home(client):
    result = client.get('/')
    assert result.status_code == 200

def test_pit_stops_year(client):
    result = client.get('/pit_stops/year')
    assert result.status_code == 200
    assert result.json == [2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2013, 2012, 2011]

def test_pit_stops_year_specific(client):
    result = client.get('/pit_stops/year/2021')
    assert result.status_code == 200
    assert result.json


def test_pit_stops_median(client):
    result = client.get('/pit_stops/medianduration/3')
    assert result.status_code == 200
    assert result.json

