import pandas as pd


def convert_str_into_time(time_str):
    time_formats = [
        '%S.%f',
        '%M:%S.%f',
        '%H:%M:%S.%f',
    ]

    for time_format in time_formats:
        try:
            datetime_obj = pd.to_datetime(time_str, format=time_format)
            return datetime_obj.time()
        except ValueError:
            pass
    return None

def convert_str_into_datetime(time_str):
    time_formats = [
        '%S.%f',
        '%M:%S.%f',
        '%H:%M:%S.%f',
    ]

    for time_format in time_formats:
        try:
            datetime_obj = pd.to_datetime(time_str, format=time_format)
            return datetime_obj.time()
        except ValueError:
            pass
    return None

def get_pit_stops():
    pit_stops_df = pd.read_csv('f1_dashboard/datasource_files/pit_stops.csv')
    pit_stops_df['duration'] = pit_stops_df['duration'].apply(convert_str_into_time)
    return pit_stops_df


def get_races():
    races_df = pd.read_csv('f1_dashboard/datasource_files/races.csv', index_col='raceId')
    races_df['date'] = pd.to_datetime(races_df['date'], format='%Y-%m-%d')
    races_df['date_year'] = races_df['date'].dt.year

    return races_df
