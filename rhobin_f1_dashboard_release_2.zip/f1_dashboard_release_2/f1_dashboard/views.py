import pandas as pd
from flask import render_template, jsonify, Blueprint

bp = Blueprint('main', __name__)

# from f1_dashboard import app
from f1_dashboard import datasource

datasource_df = datasource.process()

@bp.route('/')
def index():
    return render_template('dashboard.html')


@bp.route('/pit_stops/year')
def get_medians_of_year():
    year_series = datasource_df['year'].drop_duplicates().sort_values(ascending=False).reset_index(drop=True)
    years = year_series.to_list()
    return jsonify(years)


@bp.route('/pit_stops/year/<year>')
def get_medians_of_specific_year(year):
    year = int(year)
    data_of_year = datasource_df[datasource_df['year'] == year]
    race_names_dict = data_of_year['name'].sort_values().rename_axis('id').reset_index().to_json(orient='records')
    return jsonify(race_names_dict)


@bp.route('/pit_stops/medianduration/<id>')
def get_median_duration(id):
    id = int(id)
    record = datasource_df.loc[id]
    median = record.duration_median.strftime('%H:%M:%S.%f')
    return jsonify(median)
