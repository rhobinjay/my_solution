
function getMedianDuration(id) {
    $.ajax({
        url: '/pit_stops/medianduration/' + id,
        method: 'GET',
        success: function(response) {
            var paragraphElement = document.getElementById('median_duration');
            paragraphElement.textContent = response;
        }
    });
}

function updateTableRaceNames(year) {
    $.ajax({
        url: '/pit_stops/year/' + year,
        method: 'GET',
        success: function(races_of_year) {
            var tableBody = document.getElementById('tbl_race_name');
            tableBody.innerHTML = ''; // Clear existing content

            var newRow = document.createElement('tr');
            var newCell = document.createElement('th');

            newCell.textContent = "Race Name";
            newRow.appendChild(newCell);
            tableBody.appendChild(newRow);

            // Populate the table with new data
            var parsed_races_of_year = JSON.parse(races_of_year);
            parsed_races_of_year.forEach(function (race) {
                var newRow = document.createElement('tr');
                var newCell = document.createElement('td');
                newCell.textContent = race.name;
                newRow.id = race.id;
                newRow.appendChild(newCell);
                tableBody.appendChild(newRow);

                // Add event listener to the new row
                newRow.addEventListener("click", () => {
                    getMedianDuration(race.id);
                });
            });
        }
    });
}

function updateTableYear(year) {
    $.ajax({
        url: '/pit_stops/year',
        method: 'GET',
        success: function(data) {
            var tableBody = document.getElementById('tbl_year');
            tableBody.innerHTML = ''; // Clear existing content

            var newRow = document.createElement('tr');
            var newCell = document.createElement('th');
            newCell.textContent = "Year";
            newRow.appendChild(newCell);
            tableBody.appendChild(newRow);


            // Populate the table with new data
            data.forEach(function(value) {
                var newRow = document.createElement('tr');
                var newCell = document.createElement('td');
                newCell.textContent = value;
                newRow.id = 'year_row_' + value;
                newRow.appendChild(newCell);
                tableBody.appendChild(newRow);

                  // Add event listener to the new row
                newRow.addEventListener("click", () => {
                    updateTableRaceNames(value);
                });
            });
        }
    });
}

$(document).ready(function() {
    updateTableYear();
});
