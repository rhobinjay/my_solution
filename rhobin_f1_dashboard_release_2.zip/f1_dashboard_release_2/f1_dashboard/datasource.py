import datetime
import pandas as pd

from f1_dashboard import extract


def convert_to_datetime_with_formats(time_str):
    time_formats = [
        '%S.%f',
        '%M:%S.%f',
        '%H:%M:%S.%f',
    ]

    for time_format in time_formats:
        try:
            datetime_obj = pd.to_datetime(time_str, format=time_format)
            return datetime_obj.time()
        except ValueError:
            pass
    return None

def convert_microsecond_into_time(microsecond):
    seconds, total_microseconds = divmod(microsecond, 1000000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    time_obj = datetime.time(int(hours), int(minutes), int(seconds), int(total_microseconds))
    return time_obj

def convert_time_into_microsecond(time_obj):
    microsecond = (
        time_obj.hour * 3600000000
        + time_obj.minute * 60000000
        + time_obj.second * 1000000
        + time_obj.microsecond
    )
    return microsecond

def compute_median(series):
    # Normalize the time into microseconds
    series_ms = series.apply(convert_time_into_microsecond)
    # Compute for median
    series_median_ms = series_ms.median()
    # Convert the median back to a datetime.time object
    series_median = convert_microsecond_into_time(series_median_ms)

    return series_median


def process():
    pit_stops_df = extract.get_pit_stops()
    pit_stops_df['duration_median'] = pit_stops_df.groupby('raceId')['duration'].transform(compute_median)

    races_df = extract.get_races()
    df = pd.merge(pit_stops_df, races_df, how='left', on='raceId')
    df = df[['year', 'name', 'duration_median']]
    df = df.drop_duplicates().reset_index(drop=True)

    return df
