from pathlib import Path
from flask import Flask


def create_app():
    app = Flask(
        __name__,
        static_folder=Path(__file__).parent.joinpath('static'),
        template_folder=Path(__file__).parent.joinpath('templates')
    )

    from f1_dashboard import views
    app.register_blueprint(views.bp)

    return app

